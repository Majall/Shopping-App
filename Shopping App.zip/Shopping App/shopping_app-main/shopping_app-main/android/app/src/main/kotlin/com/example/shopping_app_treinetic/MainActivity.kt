package com.example.shopping_app_treinetic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
